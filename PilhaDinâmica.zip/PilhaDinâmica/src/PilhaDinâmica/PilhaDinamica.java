package PilhaDinâmica;
/**
 *
 * @author Lucas FreeStylee
 */
public class PilhaDinamica {
    private Node topo, inicio;                                                          //Variável topo do tipo Nó (Node).
    private int quantidade;                                                     //Variável quantidade representa quantos elementos tem na pilha.
    
    public PilhaDinamica() {                                                    //Construtor da classe PilhaDinamica
        topo = null;                                                            //Variável topo por padrão recebe null, pois o elemento na pilha é do tipo objeto.
        quantidade = 0;                                                         //Quantidade de elementos na pilha é 0 por padrão já que não inseriu um novo elemento.
        inicio = null;
    }
    
    public boolean isEmpty() {                                                  //Método que verifica se a pilha está vazia.
        return quantidade == 0;                                                 //Retorna true se a pilha está vazia e false se estiver com algum elemento.
        //return topo == null;                                                  Também podemos usar está expressão para verificar se a pilha está vazia.
    }
    
    public int size() {                                                         //MétodMétodo que verifica a quantidade de elementos dentro da pilha.
        return quantidade;                                                      //Retorna um número inteiro referente a quantidade de elementos dentro da pilha.
    }
    
    public void push(int elemento) {                                            //Método que insere elemento na pilha, recebe elemento como parâmetro.
        Node novo = new Node(elemento);                                         //Cria um novo objeto do tipo Node que recebe um elemento para armazenar.
        novo.proximo = topo;                                                    //A príncipio o próximo elemento do novo objeto criado aponta para o topo que é null.
        topo = novo;                                                            //O topo que antes apontava para null, passa agora a apontar para o novo elemento tipo Node.
        quantidade ++;                                                          //Quantidade acrescenta 1.
        if (quantidade == 1) {                                                  //Se quantidade compara com 1 for  verdadeiro - esse if serve para imprimir os valores da pilha.
            inicio = inicio.proximo;                                            //inicio sai de null para o primeiro elemento inserido na pilha e ali fica
        }
    }
    
    public int pop() {                                                          //Método que remove o elemento do topo da pilha.
        if (quantidade != 0) {                                                  //Se a pilha não está vazia, faça.
            Node aux = topo;                                                    //Cria um nó ponteiro auxiliar e faz apontar para o topo da pilha.
            topo = topo.proximo;                                                //topo vai apontar para o próximo elemento da pilha.
            aux.proximo = null;                                                 //o próximo do auxiliar é null.
            quantidade --;                                                      //Diminui 1 da quantidade.
            if (quantidade == 0) {                                              //Se quantidade for igual a 0, ou seja, se não tem elemento na pilha faça.
                inicio = null;                                                  //inicio igual null - esse if serve para imprimir os dados da pilha.
            }
            return aux.elemento;                                                //retorna o elemento que foi removido da pilha.
        }
        return -1;                                                              //Se pilha está vazia retorna -1.
    }
    
    public int top() {                                                          //Método que exibe o elemento que está no topo da pilha.
        if (quantidade != 0) {                                                  //Se a pilha não está vazia, faça.
            return topo.elemento;
        }
        return -1;                                                              //Se pilha está vazia retorna -1.
    }
    
    public void show() {
        if (isEmpty()) {
            System.out.println("Pilha Dinamica está cheia !");
        }else {
            Node atual = inicio;
            while(atual != null) {
                atual.displayNode();
                atual = atual.proximo;
            }
            System.out.println();
        }
    }

}
