package PilhaDinâmica;
/**
 *
 * @author Lucas FreeStylee
 */
public class Node {
    int elemento;                                                               //Variável de inteiros elemento.
    Node proximo;                                                               //Variável do tipo Node proximo (apontar para o próximo elemento).
    
    public Node(int elemento) {                                                 //Construtor da classe Node, recebe um parâmetro de inteiros que define o elemento armazenado.
        this.elemento = elemento;                                               //Elemento da classe Node vai receber o elemento do parâmetro.
        proximo = null;                                                         //Próximo aponta para null (vazio);
    }
    
    public void displayNode() {
        System.out.println(elemento);
    }
    
}
